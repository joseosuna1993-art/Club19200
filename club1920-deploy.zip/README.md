# Club 1920 Barber Shop — deploy

Sitio estático, sin build ni dependencias. Sube esta carpeta a Vercel (New Project → Deploy, framework: "Other") y listo.

- `index.html` — versión de escritorio del hero (totalmente responsive, también sirve el móvil real de los visitantes).
- `maqueta-movil.html` — maqueta interactiva de presentación (simulador de iPhone) para enseñar la propuesta al cliente. Accesible en `tudominio.vercel.app/maqueta-movil.html`.
